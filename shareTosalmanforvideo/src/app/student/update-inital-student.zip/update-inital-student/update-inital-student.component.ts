import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api/api.service';

@Component({
  selector: 'app-update-inital-student',
  templateUrl: './update-inital-student.component.html',
  styleUrls: ['./update-inital-student.component.scss']
})
export class UpdateInitalStudentComponent implements OnInit {
  enrolmentForm: FormGroup;
  photoFile: File | null = null;
  dataBYUsername: any;
  username: string | null = '';
  academicYears: number[] = [];

  constructor(private fb: FormBuilder, private api: ApiService, private router:Router) {
    this.enrolmentForm = this.fb.group({
      enrolmentNo: [{ value: '', disabled: true }, Validators.required],
      fullName: [{ value: '', disabled: true }, Validators.required],
      dob: [{ value: '', disabled: true }, Validators.required],
      mobileNo: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      adharNo: [{ value: '', disabled: true }, Validators.required],
      email: [{ value: '', disabled: true }, [Validators.required, Validators.email]],
      formFillOrNot: [true, Validators.required],
      fatherName: ['', Validators.required],
      fatherNo: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      fatherOccupation: ['', Validators.required],
      presentAddress: ['', Validators.required],
      presentCity: ['', Validators.required],
      presentPin: ['', Validators.required],
      presentState: ['', Validators.required],
      permanentAddress: ['', Validators.required],
      permanentCity: ['', Validators.required],
      permanentPin: ['', Validators.required],
      permanentState: ['', Validators.required],
      religion: ['', Validators.required],
      caste: ['', Validators.required],
      academicStartYear: ['', Validators.required],
      academicEndYear: ['', Validators.required],
      referenceName: ['', Validators.required],
      referenceOccupation: ['', Validators.required],
      referenceRelationship: ['', Validators.required],
      referenceResidentialAddress: ['', Validators.required],
      referenceMobileNo: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      date: ['', Validators.required],
      residencePlace: ['', Validators.required],
      education: this.fb.group({
        secondaryName: ['', Validators.required],
        secondarymarksOrGrade: ['', Validators.required],
        secondaryyear: ['', Validators.required],
        secondaryBoard: ['', Validators.required],
        latestQualification: ['', Validators.required],
        latestQualificationMarksAndGrade: ['', Validators.required],
        latestQualificationYear: ['', Validators.required],
        latestQualificationBoard: ['', Validators.required]
      }),
      photo: [null, Validators.required]
    });
  }

  ngOnInit(): void {
    this.generateAcademicYears();
    this.username = localStorage.getItem('username');
    if (this.username) {
      this.api.getStudentByUserName(this.username).subscribe(
        (successResponse: any) => {
          this.dataBYUsername = successResponse;
          this.patchFormValues();
        },
        (errorResponse) => {
          console.log(errorResponse);
        }
      );
    }
  }

  patchFormValues(): void {
    const data = this.dataBYUsername || {};
    const educationData = data.education && data.education[0] ? data.education[0] : {};
    this.enrolmentForm.patchValue({
      enrolmentNo: data.enrolmentNo || '',
      fullName: data.fullName || '',
      dob: data.dob || '',
      mobileNo: data.mobileNo || '',
      adharNo: data.adharNo || '',
      email: data.email || '',
      formFillOrNot: data.formFillOrNot || true,
      fatherName: data.fatherName || '',
      fatherNo: data.fatherNo || '',
      fatherOccupation: data.fatherOccupation || '',
      presentAddress: data.presentAddress || '',
      presentCity: data.presentCity || '',
      presentPin: data.presentPin || '',
      presentState: data.presentState || '',
      permanentAddress: data.permanentAddress || '',
      permanentCity: data.permanentCity || '',
      permanentPin: data.permanentPin || '',
      permanentState: data.permanentState || '',
      religion: data.religion || '',
      caste: data.caste || '',
      academicStartYear: data.academicStartYear || '',
      academicEndYear: data.academicEndYear || '',
      referenceName: data.referenceName || '',
      referenceOccupation: data.referenceOccupation || '',
      referenceRelationship: data.referenceRelationship || '',
      referenceResidentialAddress: data.referenceResidentialAddress || '',
      referenceMobileNo: data.referenceMobileNo || '',
      date: data.date || '',
      residencePlace: data.residencePlace || '',
      education: {
        secondaryName: educationData.secondaryName || '',
        secondarymarksOrGrade: educationData.secondarymarksOrGrade || '',
        secondaryyear: educationData.secondaryyear || '',
        secondaryBoard: educationData.secondaryBoard || '',
        latestQualification: educationData.latestQualification || '',
        latestQualificationMarksAndGrade: educationData.latestQualificationMarksAndGrade || '',
        latestQualificationYear: educationData.latestQualificationYear || '',
        latestQualificationBoard: educationData.latestQualificationBoard || ''
      }
    });

    // Revalidate the form after patching values
    this.enrolmentForm.updateValueAndValidity();
  }

  generateAcademicYears() {
    const startYear = 2050;
    const endYear = 2055;
    for (let i = endYear; i >= startYear; i--) {
      this.academicYears.push(i);
    }
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      this.photoFile = input.files[0];
      this.enrolmentForm.patchValue({
        photo: this.photoFile
      });
    }
  }


  logout(){
    this.router.navigate(['auth'])
    localStorage.clear();
  }

  onSubmit() {
    console.log(this.enrolmentForm.value);
    if (this.enrolmentForm.valid) {
      const formData = new FormData();
      const studentData = this.enrolmentForm.getRawValue();
      const educationData = this.enrolmentForm.get('education')?.value;

      const studentDataToSend = {
        enrolmentNo: studentData.enrolmentNo,
        fullName: studentData.fullName,
        dob: studentData.dob,
        mobileNo: studentData.mobileNo,
        adharNo: studentData.adharNo,
        email: studentData.email,
        formFillOrNot: studentData.formFillOrNot,
        fatherName: studentData.fatherName,
        fatherNo: studentData.fatherNo,
        fatherOccupation: studentData.fatherOccupation,
        presentAddress: studentData.presentAddress,
        presentCity: studentData.presentCity,
        presentPin: studentData.presentPin,
        presentState: studentData.presentState,
        permanentAddress: studentData.permanentAddress,
        permanentCity: studentData.permanentCity,
        permanentPin: studentData.permanentPin,
        permanentState: studentData.permanentState,
        religion: studentData.religion,
        caste: studentData.caste,
        academicStartYear: studentData.academicStartYear,
        academicEndYear: studentData.academicEndYear,
        referenceName: studentData.referenceName,
        referenceOccupation: studentData.referenceOccupation,
        referenceRelationship: studentData.referenceRelationship,
        referenceResidentialAddress: studentData.referenceResidentialAddress,
        referenceMobileNo: studentData.referenceMobileNo,
        date: studentData.date,
        residencePlace: studentData.residencePlace,
        education: [educationData]
      };

      formData.append('studentData', JSON.stringify(studentDataToSend));
      if (this.photoFile) {
        formData.append('photo', this.photoFile);
      }

      this.api.updateinitialStudent(this.username, formData).subscribe(
        (successResponse) => {
          console.log("successResponse", successResponse);
          this.router.navigate(['/student'])
        },
        (errorResponse) => {
          console.log('Error:', errorResponse);
          alert(errorResponse.error.message);
        }
      );
    } else {
      console.error('Form is invalid');
    }
  }
}
