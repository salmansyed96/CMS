import { Component } from '@angular/core';

@Component({
  selector: 'app-stinit-footer',
  templateUrl: './stinit-footer.component.html',
  styleUrls: ['./stinit-footer.component.scss']
})
export class StinitFooterComponent {

}
